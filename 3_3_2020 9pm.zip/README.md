# ENPM661 Project 2

To run this project, download all files. Run `main.py`. The program will prompt you for its run parameters. When you have finished with the parameters, the program will run. It will generate a .AVI file in the same directory, which is the animation of the solution. 